#!/usr/bin/env python3
# 🎯 Quantum-Inspired Port Scanner
# 利用多線程 + pseudo-quantum sweep (創意命名) 進行快速埠掃描

import socket
import argparse
import concurrent.futures

def scan_port(host, port):
    try:
        sock = socket.socket()
        sock.settimeout(0.5)
        sock.connect((host, port))
        return port
    except:
        return None

def quantum_sweep(host, ports):
    open_ports = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=100) as exe:
        results = exe.map(lambda p: scan_port(host, p), ports)
        for res in results:
            if res:
                open_ports.append(res)
    return open_ports

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Quantum-Inspired Port Scanner")
    parser.add_argument("--host", required=True)
    parser.add_argument("--range", required=True, help="Example: 1-1024")
    args = parser.parse_args()

    start, end = map(int, args.range.split("-"))
    ports = list(range(start, end+1))

    print(f"🚀 Starting quantum sweep on {args.host} ...")
    result = quantum_sweep(args.host, ports)

    if result:
        print("🔓 Open ports:", result)
    else:
        print("🔒 No open ports found.")
