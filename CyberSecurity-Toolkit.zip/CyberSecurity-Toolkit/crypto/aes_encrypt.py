#!/usr/bin/env python3
# 🔐 Cyber-Alchemist AES Tool
# 把字串“煉金”成密文，並可逆煉回原文。

from cryptography.fernet import Fernet
import argparse

def load_key():
    try:
        with open("secret.key", "rb") as f:
            return f.read()
    except:
        key = Fernet.generate_key()
        with open("secret.key", "wb") as f:
            f.write(key)
        return key

def encrypt(text):
    key = load_key()
    f = Fernet(key)
    return f.encrypt(text.encode()).decode()

def decrypt(token):
    key = load_key()
    f = Fernet(key)
    return f.decrypt(token.encode()).decode()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Cyber Alchemist: AES Encrypt/Decrypt")
    parser.add_argument("--encrypt", help="Text to encrypt")
    parser.add_argument("--decrypt", help="Cipher to decrypt")
    args = parser.parse_args()

    if args.encrypt:
        print("✨ Encrypted:", encrypt(args.encrypt))
    elif args.decrypt:
        print("🔓 Decrypted:", decrypt(args.decrypt))
    else:
        print("No command provided.")
