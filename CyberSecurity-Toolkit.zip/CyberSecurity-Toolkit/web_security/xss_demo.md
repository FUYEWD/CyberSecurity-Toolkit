# 🕸️ XSS Multiverse Guide  
這不是普通的 XSS 教學，而是「多重宇宙版」——  
用故事方式學習資安攻擊。

## 🌌 宇宙-01：Reflected XSS
使用者輸入 = 攻擊載具

## 🌌 宇宙-02：Stored XSS
資料庫被污染 → 全宇宙遭殃

## 🌌 宇宙-03：DOM XSS
前端是主宰世界的神，而神寫錯了字。
