#!/usr/bin/env python3
# ⚡ Quantum Port Scanner v2 — 更快、更乾淨

import socket, argparse, concurrent.futures

def scan(host, port):
    try:
        s = socket.socket()
        s.settimeout(0.3)
        s.connect((host, port))
        return port
    except: return None

if __name__ == "__main__":
    a = argparse.ArgumentParser()
    a.add_argument("--host"); a.add_argument("--range")
    args = a.parse_args()
    s,e = map(int,args.range.split("-"))
    ports = range(s,e+1)
    print("🚀 scanning", args.host)
    with concurrent.futures.ThreadPoolExecutor(80) as ex:
        res = ex.map(lambda p: scan(args.host,p), ports)
    print("open:", [r for r in res if r])
