#!/usr/bin/env python3
# 🔐 Cyber-Alchemist v2 — 更安全的自動 key 管理

from cryptography.fernet import Fernet
import argparse, os

def get_key():
    if not os.path.exists("secret.key"):
        k = Fernet.generate_key()
        open("secret.key","wb").write(k)
    return open("secret.key","rb").read()

def enc(t):
    return Fernet(get_key()).encrypt(t.encode()).decode()

def dec(t):
    return Fernet(get_key()).decrypt(t.encode()).decode()

if __name__ == "__main__":
    a=argparse.ArgumentParser()
    a.add_argument("--enc"); a.add_argument("--dec")
    x=a.parse_args()
    if x.enc: print(enc(x.enc))
    if x.dec: print(dec(x.dec))
