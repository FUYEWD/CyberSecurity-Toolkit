#!/usr/bin/env python3
# 💉 SQL Injection Playground（安全教育版）

users = ['alice','bob']
def vulnerable_login(name):
    print(f"❗ 模擬：SELECT * FROM users WHERE name = '{name}'")
    if "' OR '1'='1" in name:
        print("⚠️ Injection detected (demo)")
    elif name in users:
        print("✅ Login success")
    else:
        print("❌ Wrong user")

if __name__ == "__main__":
    name = input("輸入帳號：")
    vulnerable_login(name)
