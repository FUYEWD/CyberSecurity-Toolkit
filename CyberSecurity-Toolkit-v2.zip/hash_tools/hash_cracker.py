#!/usr/bin/env python3
# 🧩 Tiny Hash Cracker — 教學小工具

import hashlib

def crack(hash_value, wordlist):
    for w in wordlist:
        if hashlib.md5(w.encode()).hexdigest() == hash_value:
            return w
    return None

if __name__=="__main__":
    h = input("MD5: ")
    wl = ["apple","banana","123456","password"]
    res = crack(h, wl)
    print("Match:", res)
