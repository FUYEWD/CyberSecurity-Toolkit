# 📄 Security Report v2 
新增 SQLi / Hash 工具的示範紀錄。